import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import Todo from "./components/Todo.js";
import TodoList from "./components/TodoList.js";
import AddBtn from './components/AddBtn.js';
import Input from './components/Input';
//Can you see what Im typing? -Andre
//Yes! - Renoj
// Join the google meeting: meet.google.com/eyh-ygfr-gdz


// To Do List
//  Todos
//  Add Todos
//  Remove Todos
//  Search Todos - input box + search btn
//  Check Off


// Components
//  Button
//  SearchBar (TextInput)
//  Todo - Checkoff, Remove
//  AddTodoForm {TextInput, Button}


// ToDo
// Text (name)
// Checkbox (complete)
// a cross button (delete)

// 
// { 
//   text: "string",
//   check: "bool" // false - not checked // true - checked (finished)

// } 
//
class App extends Component {

  state = {
    // an array of object    
    todoList: [
      {
        text: "todo-1",
        check: false
      },
      {
        text: "todo-2",
        check: false
      },
      {
        text: "todo-3",
        check: false
      }
    ]
  }
 /* currentTodo = ()=> {
    for(let i =0; i <state.todoList.length; i++){
      let currentToDo = todoList[i];
      <Todo text={currentToDo.text} check={currentToDo.check}></Todo>
    }
  }*/


  renderTodos() {
    return this.state.todoList.map(function(currentToDo) {
              return <Todo text={currentToDo.text} check={currentToDo.check}></Todo>
    })
  }

  addTodo(text) {
    this.state.todoList.push({
      text: text,
      check: false
    })
  }

  removeTodo(id) {
    // id represents the index in the array. 
  //  use array.filter
    this.setState({todoList : this.state.todoList.filter( item => item.id !== id ) });
  }
  render() {
    console.log(this.state.todoList);

    return (
      <div className="App">
        <header className="App-header">

          {/*this.renderTodos()*/} 

          {/* <TodoList /> */}
          <AddBtn todos={this.state.todoList} />
          <Input addTodo={this.addTodo.bind(this)} />
          
        </header>
      </div>
    );
  }
} 

export default App;
