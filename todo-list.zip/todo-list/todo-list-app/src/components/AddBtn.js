import React from 'react';
import Todo from "./Todo.js";

export default class AddBtn extends React.Component {
    render(){
        const todos = this.props.todos.map( currentToDo => <Todo text={currentToDo.text} 
            check={currentToDo.check} />)

        return(
            <div>
                {todos}
            </div>            
        )
    }
}

