import React, { Component } from 'react'
import Todo from "./Todo.js";

export default class Todos extends Component {
  render() {
    return (
        {
            // this.props.todos.map( currentToDo => <Todo text={currentToDo.text} check={currentToDo.check} />)
        }
    )
  }
}
