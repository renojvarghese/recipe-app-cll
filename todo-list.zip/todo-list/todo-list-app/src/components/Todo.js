import React from "react";
//  Props
//  {    text: "string"
//      check: "bool"
//  }
export default class Todo extends React.Component  {
    render() {


        return (<li>
                 {this.props.text}
                 <br></br>
                 {this.props.check}
                 </li>);
    }

}