import React from 'react';

export default class Input extends React.Component {
    state = {
        text: ''
    }

    onSubmit = (event) => {
        event.preventDefault()
        this.setState({
          text: this.state.text
        });
      }

    handleTextChange(e) {
        e.preventDefault();
        this.setState({text : e.target.value});
    }

    handleAdd() {
        this.props.addTodo(this.state.text);
        
        console.log("are we refreshing???");
    }


    render(){
        return (
            <div>
                <input placeholder='What needs to be done?' 
                        onChange={this.handleTextChange.bind(this)} 
                        value={this.state.text} />
                <button onClick={this.handleAdd.bind(this)}>Add</button>
            </div>
        );
    }
}